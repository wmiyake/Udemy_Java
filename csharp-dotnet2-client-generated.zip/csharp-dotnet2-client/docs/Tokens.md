# IO.Swagger.Model.Tokens
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExpiresIn** | **int?** |  | [optional] 
**Type** | **string** |  | [optional] 
**AccessToken** | **string** |  | [optional] 
**RefreshToken** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

