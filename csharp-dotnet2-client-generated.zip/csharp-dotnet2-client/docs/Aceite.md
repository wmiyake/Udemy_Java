# IO.Swagger.Model.Aceite
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Aceite** | **bool?** |  | [optional] 
**Versao** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

