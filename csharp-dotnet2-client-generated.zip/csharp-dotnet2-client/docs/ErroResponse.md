# IO.Swagger.Model.ErroResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Erros** | **List&lt;Object&gt;** |  | [optional] 
**Status** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

