# IO.Swagger.Model.AccessToken
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_AccessToken** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

