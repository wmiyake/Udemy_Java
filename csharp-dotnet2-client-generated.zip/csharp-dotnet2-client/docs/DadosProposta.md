# IO.Swagger.Model.DadosProposta
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PedidoId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

