# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://hml.api.veloe.com.br/onboarding/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AceiteCpfPost**](DefaultApi.md#aceitecpfpost) | **POST** /aceite/{cpf} | Método que deve ser utilizado para registrar o aceite do termo de uso e manual do usuário
[**AuthSamlFederacaoCpfPost**](DefaultApi.md#authsamlfederacaocpfpost) | **POST** /auth-saml/federacao/{cpf} | ** Este método ainda não está fechado, ainda existem definições pendentes. Método que deve ser utilizado realizar a federação do CPF, bem como obter o token de acesso para realizar as ações(aceites, ativação, etc) na conta do cliente.
[**GatewayPagamentoAccesstokenPost**](DefaultApi.md#gatewaypagamentoaccesstokenpost) | **POST** /gateway-pagamento/accesstoken | Método para retornar AccessToken para acesso ao Gateway de Pagamento.
[**LeadCpfGet**](DefaultApi.md#leadcpfget) | **GET** /lead/{cpf} | Método que deve ser utilizado para verificar se um determinado CPF tem ou já teve relacionamento com Veloe.
[**PedidoPedidoIdPut**](DefaultApi.md#pedidopedidoidput) | **PUT** /pedido/{pedidoId} | Enviar Eventos - Api disponibilizada pelo parceiro, consumida por Veloe para enviar os eventos referentes a proposta.
[**PedidoPost**](DefaultApi.md#pedidopost) | **POST** /pedido | Registrar Proposta - Este método deve ser utilizado para submeter novas propostas. Cada proposta consiste em uma solicitação para um CPF ou CNPJ. A analise cadastral da respectiva proposta não é processada de forma online. O retorno da proposta pode ser recebido a partir da API de eventos.
[**RecargaValoresGet**](DefaultApi.md#recargavaloresget) | **GET** /recarga/valores | Método para retornar valores de recarga.


<a name="aceitecpfpost"></a>
# **AceiteCpfPost**
> Aceite AceiteCpfPost (string cpf, string authorization, string scope)

Método que deve ser utilizado para registrar o aceite do termo de uso e manual do usuário

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AceiteCpfPostExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var cpf = cpf_example;  // string | 
            var authorization = authorization_example;  // string |  (optional) 
            var scope = scope_example;  // string |  (optional) 

            try
            {
                // Método que deve ser utilizado para registrar o aceite do termo de uso e manual do usuário
                Aceite result = apiInstance.AceiteCpfPost(cpf, authorization, scope);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.AceiteCpfPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cpf** | **string**|  | 
 **authorization** | **string**|  | [optional] 
 **scope** | **string**|  | [optional] 

### Return type

[**Aceite**](Aceite.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="authsamlfederacaocpfpost"></a>
# **AuthSamlFederacaoCpfPost**
> Tokens AuthSamlFederacaoCpfPost (string cpf, string authorization, string scope)

** Este método ainda não está fechado, ainda existem definições pendentes. Método que deve ser utilizado realizar a federação do CPF, bem como obter o token de acesso para realizar as ações(aceites, ativação, etc) na conta do cliente.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AuthSamlFederacaoCpfPostExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var cpf = cpf_example;  // string | 
            var authorization = authorization_example;  // string |  (optional) 
            var scope = scope_example;  // string |  (optional) 

            try
            {
                // ** Este método ainda não está fechado, ainda existem definições pendentes. Método que deve ser utilizado realizar a federação do CPF, bem como obter o token de acesso para realizar as ações(aceites, ativação, etc) na conta do cliente.
                Tokens result = apiInstance.AuthSamlFederacaoCpfPost(cpf, authorization, scope);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.AuthSamlFederacaoCpfPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cpf** | **string**|  | 
 **authorization** | **string**|  | [optional] 
 **scope** | **string**|  | [optional] 

### Return type

[**Tokens**](Tokens.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gatewaypagamentoaccesstokenpost"></a>
# **GatewayPagamentoAccesstokenPost**
> AccessToken GatewayPagamentoAccesstokenPost (string token, string authorization)

Método para retornar AccessToken para acesso ao Gateway de Pagamento.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GatewayPagamentoAccesstokenPostExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var token = token_example;  // string | Token gerado na autenticação (optional) 
            var authorization = authorization_example;  // string | chave veloe - fornecida por parceiro (optional) 

            try
            {
                // Método para retornar AccessToken para acesso ao Gateway de Pagamento.
                AccessToken result = apiInstance.GatewayPagamentoAccesstokenPost(token, authorization);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GatewayPagamentoAccesstokenPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **string**| Token gerado na autenticação | [optional] 
 **authorization** | **string**| chave veloe - fornecida por parceiro | [optional] 

### Return type

[**AccessToken**](AccessToken.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="leadcpfget"></a>
# **LeadCpfGet**
> LeadStatus LeadCpfGet (string cpf, string token, string authorization)

Método que deve ser utilizado para verificar se um determinado CPF tem ou já teve relacionamento com Veloe.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LeadCpfGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var cpf = cpf_example;  // string | 
            var token = token_example;  // string | Token gerado na autenticação (optional) 
            var authorization = authorization_example;  // string | chave veloe - fornecida por parceiro (optional) 

            try
            {
                // Método que deve ser utilizado para verificar se um determinado CPF tem ou já teve relacionamento com Veloe.
                LeadStatus result = apiInstance.LeadCpfGet(cpf, token, authorization);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.LeadCpfGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cpf** | **string**|  | 
 **token** | **string**| Token gerado na autenticação | [optional] 
 **authorization** | **string**| chave veloe - fornecida por parceiro | [optional] 

### Return type

[**LeadStatus**](LeadStatus.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="pedidopedidoidput"></a>
# **PedidoPedidoIdPut**
> void PedidoPedidoIdPut (string pedidoId, Eventos status, string token, string authorization)

Enviar Eventos - Api disponibilizada pelo parceiro, consumida por Veloe para enviar os eventos referentes a proposta.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PedidoPedidoIdPutExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var pedidoId = pedidoId_example;  // string | 
            var status = new Eventos(); // Eventos | 
            var token = token_example;  // string | Token gerado na autenticação (optional) 
            var authorization = authorization_example;  // string | chave veloe - fornecida por parceiro (optional) 

            try
            {
                // Enviar Eventos - Api disponibilizada pelo parceiro, consumida por Veloe para enviar os eventos referentes a proposta.
                apiInstance.PedidoPedidoIdPut(pedidoId, status, token, authorization);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PedidoPedidoIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pedidoId** | **string**|  | 
 **status** | [**Eventos**](Eventos.md)|  | 
 **token** | **string**| Token gerado na autenticação | [optional] 
 **authorization** | **string**| chave veloe - fornecida por parceiro | [optional] 

### Return type

void (empty response body)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="pedidopost"></a>
# **PedidoPost**
> DadosProposta PedidoPost (Pedido pedido, string token, string authorization)

Registrar Proposta - Este método deve ser utilizado para submeter novas propostas. Cada proposta consiste em uma solicitação para um CPF ou CNPJ. A analise cadastral da respectiva proposta não é processada de forma online. O retorno da proposta pode ser recebido a partir da API de eventos.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PedidoPostExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var pedido = new Pedido(); // Pedido | 
            var token = token_example;  // string | Token gerado na autenticação (optional) 
            var authorization = authorization_example;  // string | chave do parceiro - fornecida por veloe (optional) 

            try
            {
                // Registrar Proposta - Este método deve ser utilizado para submeter novas propostas. Cada proposta consiste em uma solicitação para um CPF ou CNPJ. A analise cadastral da respectiva proposta não é processada de forma online. O retorno da proposta pode ser recebido a partir da API de eventos.
                DadosProposta result = apiInstance.PedidoPost(pedido, token, authorization);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PedidoPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pedido** | [**Pedido**](Pedido.md)|  | 
 **token** | **string**| Token gerado na autenticação | [optional] 
 **authorization** | **string**| chave do parceiro - fornecida por veloe | [optional] 

### Return type

[**DadosProposta**](DadosProposta.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="recargavaloresget"></a>
# **RecargaValoresGet**
> ValoresRecarga RecargaValoresGet (string token, string authorization)

Método para retornar valores de recarga.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RecargaValoresGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: authorization
            Configuration.Default.ApiKey.Add("Unused", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Unused", "Bearer");

            var apiInstance = new DefaultApi();
            var token = token_example;  // string | Token gerado na autenticação (optional) 
            var authorization = authorization_example;  // string | chave veloe - fornecida por parceiro (optional) 

            try
            {
                // Método para retornar valores de recarga.
                ValoresRecarga result = apiInstance.RecargaValoresGet(token, authorization);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.RecargaValoresGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **string**| Token gerado na autenticação | [optional] 
 **authorization** | **string**| chave veloe - fornecida por parceiro | [optional] 

### Return type

[**ValoresRecarga**](ValoresRecarga.md)

### Authorization

[authorization](../README.md#authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

