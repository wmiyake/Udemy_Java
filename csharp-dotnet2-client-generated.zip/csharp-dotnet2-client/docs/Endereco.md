# IO.Swagger.Model.Endereco
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cep** | **string** |  | 
**Uf** | **string** | estado do Brasil | 
**Cidade** | **string** | cidade do Brasil | 
**Bairro** | **string** |  | 
**Logradouro** | **string** |  | 
**Numero** | **string** |  | 
**Complemento** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

