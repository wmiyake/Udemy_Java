using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Aceite {
    /// <summary>
    /// Gets or Sets _Aceite
    /// </summary>
    [DataMember(Name="aceite", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "aceite")]
    public bool? _Aceite { get; set; }

    /// <summary>
    /// Gets or Sets Versao
    /// </summary>
    [DataMember(Name="versao", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "versao")]
    public string Versao { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Aceite {\n");
      sb.Append("  _Aceite: ").Append(_Aceite).Append("\n");
      sb.Append("  Versao: ").Append(Versao).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
