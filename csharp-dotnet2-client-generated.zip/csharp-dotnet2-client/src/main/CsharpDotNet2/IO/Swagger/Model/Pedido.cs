using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// solicitação de pedido
  /// </summary>
  [DataContract]
  public class Pedido {
    /// <summary>
    /// Gets or Sets PropostaPF
    /// </summary>
    [DataMember(Name="propostaPF", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "propostaPF")]
    public Object PropostaPF { get; set; }

    /// <summary>
    /// Gets or Sets PropostaPJ
    /// </summary>
    [DataMember(Name="propostaPJ", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "propostaPJ")]
    public Object PropostaPJ { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Pedido {\n");
      sb.Append("  PropostaPF: ").Append(PropostaPF).Append("\n");
      sb.Append("  PropostaPJ: ").Append(PropostaPJ).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
