using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IDefaultApi
    {
        /// <summary>
        /// Método que deve ser utilizado para registrar o aceite do termo de uso e manual do usuário 
        /// </summary>
        /// <param name="cpf"></param>
        /// <param name="authorization"></param>
        /// <param name="scope"></param>
        /// <returns>Aceite</returns>
        Aceite AceiteCpfPost (string cpf, string authorization, string scope);
        /// <summary>
        /// ** Este método ainda não está fechado, ainda existem definições pendentes. Método que deve ser utilizado realizar a federação do CPF, bem como obter o token de acesso para realizar as ações(aceites, ativação, etc) na conta do cliente. 
        /// </summary>
        /// <param name="cpf"></param>
        /// <param name="authorization"></param>
        /// <param name="scope"></param>
        /// <returns>Tokens</returns>
        Tokens AuthSamlFederacaoCpfPost (string cpf, string authorization, string scope);
        /// <summary>
        /// Método para retornar AccessToken para acesso ao Gateway de Pagamento. 
        /// </summary>
        /// <param name="token">Token gerado na autenticação</param>
        /// <param name="authorization">chave veloe - fornecida por parceiro</param>
        /// <returns>AccessToken</returns>
        AccessToken GatewayPagamentoAccesstokenPost (string token, string authorization);
        /// <summary>
        /// Método que deve ser utilizado para verificar se um determinado CPF tem ou já teve relacionamento com Veloe. 
        /// </summary>
        /// <param name="cpf"></param>
        /// <param name="token">Token gerado na autenticação</param>
        /// <param name="authorization">chave veloe - fornecida por parceiro</param>
        /// <returns>LeadStatus</returns>
        LeadStatus LeadCpfGet (string cpf, string token, string authorization);
        /// <summary>
        /// Enviar Eventos - Api disponibilizada pelo parceiro, consumida por Veloe para enviar os eventos referentes a proposta. 
        /// </summary>
        /// <param name="pedidoId"></param>
        /// <param name="status"></param>
        /// <param name="token">Token gerado na autenticação</param>
        /// <param name="authorization">chave veloe - fornecida por parceiro</param>
        /// <returns></returns>
        void PedidoPedidoIdPut (string pedidoId, Eventos status, string token, string authorization);
        /// <summary>
        /// Registrar Proposta - Este método deve ser utilizado para submeter novas propostas. Cada proposta consiste em uma solicitação para um CPF ou CNPJ. A analise cadastral da respectiva proposta não é processada de forma online. O retorno da proposta pode ser recebido a partir da API de eventos. 
        /// </summary>
        /// <param name="pedido"></param>
        /// <param name="token">Token gerado na autenticação</param>
        /// <param name="authorization">chave do parceiro - fornecida por veloe</param>
        /// <returns>DadosProposta</returns>
        DadosProposta PedidoPost (Pedido pedido, string token, string authorization);
        /// <summary>
        /// Método para retornar valores de recarga. 
        /// </summary>
        /// <param name="token">Token gerado na autenticação</param>
        /// <param name="authorization">chave veloe - fornecida por parceiro</param>
        /// <returns>ValoresRecarga</returns>
        ValoresRecarga RecargaValoresGet (string token, string authorization);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class DefaultApi : IDefaultApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public DefaultApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultApi"/> class.
        /// </summary>
        /// <returns></returns>
        public DefaultApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Método que deve ser utilizado para registrar o aceite do termo de uso e manual do usuário 
        /// </summary>
        /// <param name="cpf"></param> 
        /// <param name="authorization"></param> 
        /// <param name="scope"></param> 
        /// <returns>Aceite</returns>            
        public Aceite AceiteCpfPost (string cpf, string authorization, string scope)
        {
            
            // verify the required parameter 'cpf' is set
            if (cpf == null) throw new ApiException(400, "Missing required parameter 'cpf' when calling AceiteCpfPost");
            
    
            var path = "/aceite/{cpf}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "cpf" + "}", ApiClient.ParameterToString(cpf));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
 if (scope != null) headerParams.Add("scope", ApiClient.ParameterToString(scope)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling AceiteCpfPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling AceiteCpfPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Aceite) ApiClient.Deserialize(response.Content, typeof(Aceite), response.Headers);
        }
    
        /// <summary>
        /// ** Este método ainda não está fechado, ainda existem definições pendentes. Método que deve ser utilizado realizar a federação do CPF, bem como obter o token de acesso para realizar as ações(aceites, ativação, etc) na conta do cliente. 
        /// </summary>
        /// <param name="cpf"></param> 
        /// <param name="authorization"></param> 
        /// <param name="scope"></param> 
        /// <returns>Tokens</returns>            
        public Tokens AuthSamlFederacaoCpfPost (string cpf, string authorization, string scope)
        {
            
            // verify the required parameter 'cpf' is set
            if (cpf == null) throw new ApiException(400, "Missing required parameter 'cpf' when calling AuthSamlFederacaoCpfPost");
            
    
            var path = "/auth-saml/federacao/{cpf}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "cpf" + "}", ApiClient.ParameterToString(cpf));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
 if (scope != null) headerParams.Add("scope", ApiClient.ParameterToString(scope)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling AuthSamlFederacaoCpfPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling AuthSamlFederacaoCpfPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Tokens) ApiClient.Deserialize(response.Content, typeof(Tokens), response.Headers);
        }
    
        /// <summary>
        /// Método para retornar AccessToken para acesso ao Gateway de Pagamento. 
        /// </summary>
        /// <param name="token">Token gerado na autenticação</param> 
        /// <param name="authorization">chave veloe - fornecida por parceiro</param> 
        /// <returns>AccessToken</returns>            
        public AccessToken GatewayPagamentoAccesstokenPost (string token, string authorization)
        {
            
    
            var path = "/gateway-pagamento/accesstoken";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (token != null) headerParams.Add("token", ApiClient.ParameterToString(token)); // header parameter
 if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GatewayPagamentoAccesstokenPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GatewayPagamentoAccesstokenPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (AccessToken) ApiClient.Deserialize(response.Content, typeof(AccessToken), response.Headers);
        }
    
        /// <summary>
        /// Método que deve ser utilizado para verificar se um determinado CPF tem ou já teve relacionamento com Veloe. 
        /// </summary>
        /// <param name="cpf"></param> 
        /// <param name="token">Token gerado na autenticação</param> 
        /// <param name="authorization">chave veloe - fornecida por parceiro</param> 
        /// <returns>LeadStatus</returns>            
        public LeadStatus LeadCpfGet (string cpf, string token, string authorization)
        {
            
            // verify the required parameter 'cpf' is set
            if (cpf == null) throw new ApiException(400, "Missing required parameter 'cpf' when calling LeadCpfGet");
            
    
            var path = "/lead/{cpf}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "cpf" + "}", ApiClient.ParameterToString(cpf));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (token != null) headerParams.Add("token", ApiClient.ParameterToString(token)); // header parameter
 if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling LeadCpfGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling LeadCpfGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (LeadStatus) ApiClient.Deserialize(response.Content, typeof(LeadStatus), response.Headers);
        }
    
        /// <summary>
        /// Enviar Eventos - Api disponibilizada pelo parceiro, consumida por Veloe para enviar os eventos referentes a proposta. 
        /// </summary>
        /// <param name="pedidoId"></param> 
        /// <param name="status"></param> 
        /// <param name="token">Token gerado na autenticação</param> 
        /// <param name="authorization">chave veloe - fornecida por parceiro</param> 
        /// <returns></returns>            
        public void PedidoPedidoIdPut (string pedidoId, Eventos status, string token, string authorization)
        {
            
            // verify the required parameter 'pedidoId' is set
            if (pedidoId == null) throw new ApiException(400, "Missing required parameter 'pedidoId' when calling PedidoPedidoIdPut");
            
            // verify the required parameter 'status' is set
            if (status == null) throw new ApiException(400, "Missing required parameter 'status' when calling PedidoPedidoIdPut");
            
    
            var path = "/pedido/{pedidoId}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "pedidoId" + "}", ApiClient.ParameterToString(pedidoId));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (token != null) headerParams.Add("token", ApiClient.ParameterToString(token)); // header parameter
 if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
                        postBody = ApiClient.Serialize(status); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PedidoPedidoIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PedidoPedidoIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Registrar Proposta - Este método deve ser utilizado para submeter novas propostas. Cada proposta consiste em uma solicitação para um CPF ou CNPJ. A analise cadastral da respectiva proposta não é processada de forma online. O retorno da proposta pode ser recebido a partir da API de eventos. 
        /// </summary>
        /// <param name="pedido"></param> 
        /// <param name="token">Token gerado na autenticação</param> 
        /// <param name="authorization">chave do parceiro - fornecida por veloe</param> 
        /// <returns>DadosProposta</returns>            
        public DadosProposta PedidoPost (Pedido pedido, string token, string authorization)
        {
            
            // verify the required parameter 'pedido' is set
            if (pedido == null) throw new ApiException(400, "Missing required parameter 'pedido' when calling PedidoPost");
            
    
            var path = "/pedido";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (token != null) headerParams.Add("token", ApiClient.ParameterToString(token)); // header parameter
 if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
                        postBody = ApiClient.Serialize(pedido); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PedidoPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PedidoPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (DadosProposta) ApiClient.Deserialize(response.Content, typeof(DadosProposta), response.Headers);
        }
    
        /// <summary>
        /// Método para retornar valores de recarga. 
        /// </summary>
        /// <param name="token">Token gerado na autenticação</param> 
        /// <param name="authorization">chave veloe - fornecida por parceiro</param> 
        /// <returns>ValoresRecarga</returns>            
        public ValoresRecarga RecargaValoresGet (string token, string authorization)
        {
            
    
            var path = "/recarga/valores";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (token != null) headerParams.Add("token", ApiClient.ParameterToString(token)); // header parameter
 if (authorization != null) headerParams.Add("Authorization", ApiClient.ParameterToString(authorization)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] { "authorization" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling RecargaValoresGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling RecargaValoresGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ValoresRecarga) ApiClient.Deserialize(response.Content, typeof(ValoresRecarga), response.Headers);
        }
    
    }
}
