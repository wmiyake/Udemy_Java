package controle;

public class IfElse {

    public static void main(String[] args){
        double nota = 6.5;

        if(nota >= 7){
            System.out.println("Aprovado!");
            System.out.println("Parabens!");
        } else {
            System.out.println("Recuperação");
        }
    }
}