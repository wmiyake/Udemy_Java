package oo.polimorfismo;

public class Feijao extends Comida  {

}
