package oo.encapsulamento.casa1;

public class Sogro {
	
	public boolean gostaDeCerveja = true;
}
