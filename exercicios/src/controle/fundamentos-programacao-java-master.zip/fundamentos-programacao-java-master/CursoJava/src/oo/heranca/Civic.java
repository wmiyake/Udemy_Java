package oo.heranca;

public class Civic extends Carro {

}
