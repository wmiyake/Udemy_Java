package oo.polimorfismo;

public class Sorvete extends Comida {
	
}
