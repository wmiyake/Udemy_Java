package oo.encapsulamento.casa1;

public class Sogra {
	
	protected String segredoDeFamilia = "Temos uma conta na suiça";
}
