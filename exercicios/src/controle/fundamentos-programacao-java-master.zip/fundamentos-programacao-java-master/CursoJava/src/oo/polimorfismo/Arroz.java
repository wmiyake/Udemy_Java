package oo.polimorfismo;

public class Arroz extends Comida{

}
