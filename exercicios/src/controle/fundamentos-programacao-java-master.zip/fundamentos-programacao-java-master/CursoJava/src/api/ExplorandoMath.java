package api;

public class ExplorandoMath {

	public static void main(String[] args) {
		// sin, cos, tag, log...
		System.out.println(Math.PI);
		System.out.println(Math.pow(2, 3));
		System.out.println(Math.abs(-10.5));
		System.out.println(Math.min(70, 7));
		System.out.println(Math.max(70, 7));
		System.out.println(Math.ceil(6.55)); // Prof. Legal
		System.out.println(Math.floor(6.55)); // Prof. Otário
		System.out.println(Math.random());
		// Math.

	}

}
