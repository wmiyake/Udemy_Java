package fundamentos;

public class OperadoresRelacionais {

    public static void main(String[] args){
        // Operadores: == != >= > <= <
        int num1 = 97;
        int num2 = 'a';
        System.out.println(num1 == num2);
        System.out.println(3 != 2);
        System.out.println(3 >= 2);
        System.out.println(3 > 2);
        System.out.println(3 <= 3);
        System.out.println(3 < 4);
    }
}