package fundamentos;

import java.awt.Button;
import java.util.Date;

public class Import {

    public static void main(String[] args){
        Double a = 2.0;
        System.out.println("...");

        Button b;
        Date d;
    }
}