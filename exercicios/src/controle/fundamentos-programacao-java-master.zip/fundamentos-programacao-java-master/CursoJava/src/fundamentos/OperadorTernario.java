package fundamentos;

public class OperadorTernario{

    public static void main(String[] args){
        double nota = 8.0;
        String resultado = nota >= 7 ? "Aprovado" : "Recuperação";
        System.out.println(resultado);
    }
}