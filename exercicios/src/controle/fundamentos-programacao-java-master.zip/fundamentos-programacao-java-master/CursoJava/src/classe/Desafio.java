package classe;

public class Desafio {
	
	int a = 2;

	public static void main(String[] args) {
		Desafio d = new Desafio();
		System.out.println(d.a);

	}

}
