package classe;

public class ValorPadrao {
	
	static boolean a;

	public static void main(String[] args) {
		System.out.println(a);
		
		Object b = null;
		System.out.println(b);
		
	}

}
