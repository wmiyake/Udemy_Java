package classes;

public class Exercicio13 {
	/**
	 * Crie uma classe Data com os seguintes atributos: Dia, Mês e Ano. Verifique
	 * antes da inicialização de um objeto Data se a data inserida é válida;
	 */

	int dia;
	int mes;
	int ano;
}
