package classes;

/**
 * 11. Modele uma classe Pessoa, com os seguintes atributos: Nome, Idade,
 * Altura, CPF, Data de nascimento.
 */
public class Exercicio11 {

	String nome;

	int idade;

	float altura;

	String cpf;

	String datanascimento;

}
