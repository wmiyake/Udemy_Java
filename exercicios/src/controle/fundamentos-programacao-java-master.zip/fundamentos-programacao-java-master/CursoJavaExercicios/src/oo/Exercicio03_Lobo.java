package oo;

public class Exercicio03_Lobo extends Exercicio03_Animal {

	public Exercicio03_Lobo(String nome, float peso, String som) {
		this.nome = nome;
		this.peso = peso;
		this.som = som;
	}
}
