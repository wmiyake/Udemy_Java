package oo;

public class Exercicio04_Midia {
	/**
	 * 4. Implementação de uma plataforma de broadcast de vídeos e músicas. Criar
	 * uma classe Mídia com os seguintes membros: Tamanho do arquivo, Método para
	 * dar play na mídia e Método para dar pause na mídia. Criar uma subclasse Vídeo
	 * com os seguintes membros: Qualidade Método que permita ver o vídeo em tela
	 * cheia. Criar uma subclasse Música com os seguintes atributos: Artista, Álbum
	 * e Gênero. De última hora apareceu como demanda a adaptação do código para que
	 * a plataforma aceite fotos também. Leve em consideração que fotos não podem
	 * utilizar o método play nem o método pause; A classe Foto deve possuir no
	 * mínimo os seguintes membros: Extensão do arquivo e Método para mostrar a
	 * foto.
	 */

	float tamanho_do_arquivo;

}
