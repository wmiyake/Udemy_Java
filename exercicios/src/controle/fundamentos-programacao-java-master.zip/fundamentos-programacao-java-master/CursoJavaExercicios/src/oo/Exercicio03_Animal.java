package oo;

public class Exercicio03_Animal {
	/**
	 * 3. Criar uma classe Animal com os seguintes atributos: Nome e Peso. Na classe
	 * Animal crie um método que imprime no console o som que o animal faz. Crie as
	 * seguintes subclasses: Leão, Macaco e Lobo. Crie uma classe Zoológico, com uma
	 * lista de animais. Apresente o som de cada animal do Zoológico.
	 */

	String nome;
	float peso;
	String som;

	void som() {
		System.out.println(this.som);
	}
}
