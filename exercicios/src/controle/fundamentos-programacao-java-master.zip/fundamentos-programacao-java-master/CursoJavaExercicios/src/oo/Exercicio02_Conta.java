package oo;

public class Exercicio02_Conta {
	/**
	 * 2. Criar uma classe Conta com os atributos: Agência, Conta e Titular. Criar
	 * uma subclasse ContaCorrente. Implemente um construtor para a classe
	 * ContaCorrente. Criar uma subclasse ContaPoupança com o seguinte atributo:
	 * Juros. Implemente um construtor para a classe ContaPoupança.
	 */

	int agencia;
	int conta;
	String titular;

}
