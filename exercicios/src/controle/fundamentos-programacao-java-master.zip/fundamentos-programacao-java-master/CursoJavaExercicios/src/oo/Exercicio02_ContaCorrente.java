package oo;

public class Exercicio02_ContaCorrente extends Exercicio02_Conta {

	public Exercicio02_ContaCorrente(int agencia, int conta, String titular) {
		this.agencia = agencia;
		this.conta = conta;
		this.titular = titular;
	}

}
