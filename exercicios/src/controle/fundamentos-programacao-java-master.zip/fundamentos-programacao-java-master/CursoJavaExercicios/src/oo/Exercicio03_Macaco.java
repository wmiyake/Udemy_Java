package oo;

public class Exercicio03_Macaco extends Exercicio03_Animal {
	
	public Exercicio03_Macaco(String nome, float peso, String som) {
		this.nome = nome;
		this.peso = peso;
		this.som = som;
	}
}
